CREATE TABLESPACE ABDDBA_TBLS_Personas 
    ADD DATAFILE 'ABDDBA_DF_personas.ibd' Engine=InnoDB;

CREATE TABLESPACE ABDDBA_TBLS_Cursos 
    ADD DATAFILE 'ABDDBA_DF_cursos.ibd' Engine=InnoDB;

CREATE TABLESPACE ABDDBA_TBLS_Matriculados 
    ADD DATAFILE 'ABDDBA_DF_matriculados.ibd' Engine=InnoDB;
    
