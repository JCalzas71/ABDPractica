DROP TABLE pracabd1.personas;

DROP TABLE pracabd1.matriculados;

DROP TABLE pracabd1.cursos;