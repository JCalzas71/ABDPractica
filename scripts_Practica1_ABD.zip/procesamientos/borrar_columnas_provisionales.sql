ALTER TABLE pracabd1.personas DROP en_paro_provisional;

ALTER TABLE pracabd1.personas DROP canal_provisional;

ALTER TABLE pracabd1.personas DROP cod_postal_provisional;

ALTER TABLE pracabd1.personas DROP fecha_provisional;

ALTER TABLE pracabd1.matriculados DROP matriculado_provisional;
