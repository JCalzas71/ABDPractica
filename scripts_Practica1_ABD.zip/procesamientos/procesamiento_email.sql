UPDATE pracabd1.personas
SET email = REPLACE(email, 'ñ', 'n');

UPDATE pracabd1.personas
SET email = REPLACE(email, 'á', 'a');

UPDATE pracabd1.personas
SET email = REPLACE(email, 'é', 'e');

UPDATE pracabd1.personas
SET email = REPLACE(email, 'í', 'i');

UPDATE pracabd1.personas
SET email = REPLACE(email, 'ó', 'o');

UPDATE pracabd1.personas
SET email = REPLACE(email, 'ú', 'u');
