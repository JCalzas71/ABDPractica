-- Consulta 1
DROP INDEX nombre
ON pracabd1.personas;

DROP INDEX apellidos
ON pracabd1.personas;

-- Consulta 2
DROP INDEX paro
ON pracabd1.personas;

-- Consulta 3
DROP INDEX provincia
ON pracabd1.personas;

-- Consulta 4
DROP INDEX apellidos
ON pracabd1.personas;

DROP INDEX provincia
ON pracabd1.personas;

DROP INDEX edicion
ON pracabd1.cursos;

-- Consulta 6
DROP INDEX apellidos
ON pracabd1.personas;

DROP INDEX area
ON pracabd1.cursos;

-- Consulta 7
DROP INDEX edicion
ON pracabd1.cursos;

DROP INDEX area
ON pracabd1.cursos;

