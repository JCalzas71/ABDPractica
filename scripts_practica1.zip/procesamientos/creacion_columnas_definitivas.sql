ALTER TABLE pracabd1.personas
ADD en_paro INTEGER;

ALTER TABLE pracabd1.personas
ADD canal INTEGER;

ALTER TABLE pracabd1.personas
ADD fecha DATE;

ALTER TABLE pracabd1.personas
ADD cod_postal INTEGER;

ALTER TABLE pracabd1.matriculados
ADD matriculado INTEGER;