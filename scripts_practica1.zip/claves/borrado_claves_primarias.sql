ALTER TABLE pracabd1.cursos
DROP primary key;

ALTER TABLE pracabd1.matriculados 
DROP primary key;

ALTER TABLE pracabd1.personas 
DROP primary key;