ALTER TABLE pracabd1.matriculados
DROP foreign key fk_persona;

ALTER TABLE pracabd1.matriculados
DROP foreign key fk_curso;
